<?php
// Include necessary files and functions for sending messages
include 'sendmsg.php'; // Ensure you have the appropriate functions in sendmsg.php for sending messages

// Function to send a message and return success or error message
function sendBulkMessage($token, $phone, $message) {
    // Call the sendMessage function from sendmsg.php
    $response = sendMessage($token, $phone, $message);

    // Process the response and return success or error message
    if ($response === true) {
        return "Message sent successfully to $phone.";
    } else {
        return "Error sending message to $phone: $response";
    }
}

// Function to validate phone number format
function isValidPhoneNumber($phoneNumber) {
    // Implement your validation logic here
    // For example, check if the phone number meets certain criteria
    // Return true if it's a valid number, false otherwise
    return preg_match('/^\+?\d+$/', $phoneNumber);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit"])) {
    if (isset($_FILES['csv_file']) && $_FILES['csv_file']['error'] === UPLOAD_ERR_OK) {
        $csvFilePath = $_FILES['csv_file']['tmp_name'];

        // Load the CSV file
        $data = [];
        if (($handle = fopen($csvFilePath, "r")) !== false) {
            while (($row = fgetcsv($handle, 1000, ",")) !== false) {
                $row = array_map('trim', $row); // Trim whitespace from each element in the row
                if (count($row) >= 2) {
                    $phone = $row[0];
                    $message = $row[1];

                    if (!isValidPhoneNumber($phone)) {
                        echo "Invalid phone number: $phone. Skipping...<br>";
                        continue; // Skip sending message for invalid phone number
                    }

                    // Display fetched phone number and message
                    echo "Phone: $phone, Message: $message<br>";

                    // Send the message and display success or error message
                    echo sendBulkMessage($token, $phone, $message) . "<br>";

                    // Sleep for a certain duration before sending the next message (optional)
                    sleep(1); // Adjust this value based on API limitations or requirements
                } else {
                    echo "Invalid data format in CSV. Each row should contain at least phone number and message.<br>";
                    // Continue to the next row
                    continue;
                }
            }
            fclose($handle);
        } else {
            echo "Error opening the CSV file.";
            exit;
        }

        echo "All messages have been sent.";
    } else {
        echo "Please upload a CSV file.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Head content -->
</head>
<body>
    <!-- Form to input CSV file -->
    <div class="content">
        <h2>Send Bulk Messages from CSV</h2>
       <form method="post" enctype="multipart/form-data">
            <label for="csv_file">Upload CSV File:</label>
            <input type="file" name="csv_file">
    <input type="submit" name="submit" value="Upload CSV">
</form>
    </div>
</body>
</html>
