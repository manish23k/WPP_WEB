<?php include 'header.php'; ?>

<?php
// Replace these with your actual database details
$host = 'localhost';
$user = 'cron';
$password = '1234';
$database = 'asterisk';


// Create database connection
$conn = new mysqli($host, $user, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to add a new template
function addTemplate($name, $content)
{
    global $conn;
    $sql = "INSERT INTO message_templates (template_name, template_content) VALUES ('$name', '$content')";
    return $conn->query($sql);
}

// Function to edit an existing template
function editTemplate($id, $name, $content)
{
    global $conn;
    $sql = "UPDATE message_templates SET template_name='$name', template_content='$content' WHERE template_id=$id";
    return $conn->query($sql);
}

// Function to delete a template
function deleteTemplate($id)
{
    global $conn;
    $sql = "DELETE FROM message_templates WHERE template_id=$id";
    return $conn->query($sql);
}

// Handle form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["add"])) {
        $template_name = $_POST["template_name"];
        $template_content = $_POST["template_content"];
        addTemplate($template_name, $template_content);
    } elseif (isset($_POST["edit"])) {
        $template_id = $_POST["template_id"];
        // Fetch template data for editing
        $result = $conn->query("SELECT * FROM message_templates WHERE template_id=$template_id");
        $row = $result->fetch_assoc();
        $template_name = $row['template_name'];
        $template_content = $row['template_content'];
    } elseif (isset($_POST["update"])) {
        $template_id = $_POST["template_id"];
        $template_name = $_POST["template_name"];
        $template_content = $_POST["template_content"];
        editTemplate($template_id, $template_name, $template_content);
    } elseif (isset($_POST["delete"])) {
        $template_id = $_POST["template_id"];
        deleteTemplate($template_id);
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Message Templates</title>
    <style>
        body {
            font-family: 'Helvetica', sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
        }

        h2 {
            color: #075e54;
        }

        form {
            background-color: #fff;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #075e54;
            color: #fff;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #ddd;
        }

        button {
            background-color: #25d366;
            color: #fff;
            border: none;
            padding: 8px 12px;
            cursor: pointer;
            border-radius: 3px;
        }

        button:hover {
            background-color: #128C7E;
        }

        textarea {
            width: 100%;
            padding: 10px;
            box-sizing: border-box;
            margin-top: 8px;
            margin-bottom: 16px;
            resize: vertical;
            border: 3px solid #ddd;
            border-radius: 3px;
        }

        input[type="text"] {
            width: calc(100% - 22px);
            padding: 10px;
            box-sizing: border-box;
            margin-top: 8px;
            margin-bottom: 16px;
            border: 1px solid #ddd;
            border-radius: 3px;
        }

        /* WhatsApp Web-like theme */
        .header {
            background-color: #128C7E;
            color: #fff;
            padding: 10px;
            text-align: center;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
        }
    </style>
</head>

<body>

    <!-- <div class="header">
        <h2>Message Templates</h2>
    </div> -->

    <div class="container">

        <!-- Add New Template Form -->
        <h2>Add New Template</h2>
        <form method="post" action="">
            <label for="template_name">Template Name:</label>
            <input type="text" name="template_name" required>
            <br>
            <label for="template_content">Template Content:</label>
            <textarea name="template_content" required></textarea>
            <br>
            <button type="submit" name="add">Add Template</button>
        </form>

        <!-- Existing Templates Table -->
        <h2>Existing Templates</h2>
        <table>
            <tr>
                <th>Template ID</th>
                <th>Template Name</th>
                <th>Template Content</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>

            <?php
            // Fetch existing templates from the database
            $result = $conn->query("SELECT * FROM message_templates");

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                        <td>{$row['template_id']}</td>
                        <td>{$row['template_name']}</td>
                        <td>{$row['template_content']}</td>
                        <td>
                            <form method='post' action=''>
                                <input type='hidden' name='template_id' value='{$row['template_id']}'>
                                <button type='submit' name='edit'>Edit</button>
                            </form>
                        </td>
                        <td>
                            <form method='post' action=''>
                                <input type='hidden' name='template_id' value='{$row['template_id']}'>
                                <button type='submit' name='delete'>Delete</button>
                            </form>
                        </td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='5'>No templates found</td></tr>";
            }
            ?>
        </table>

        <?php
        // Display the form for editing
        if (isset($_POST["edit"])) {
            ?>
            <!-- Edit Template Form -->
            <h2>Edit Template</h2>
            <form method="post" action="">
                <input type="hidden" name="template_id" value="<?= $template_id ?>">
                <label for="template_name">Template Name:</label>
                <input type="text" name="template_name" value="<?= $template_name ?>" required>
                <br>
                <label for="template_content">Template Content:</label>
                <textarea name="template_content" required><?= $template_content ?></textarea>
                <br>
                <button type="submit" name="update">Update Template</button>
            </form>
            <?php
        }
        ?>

    </div>

</body>

</html>