<?php include 'header.php'; ?>

<?php
//require_once 'apiRequests.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

$sessionname = "default";
$tokenFilePath = 'token.txt';
$token = file_exists($tokenFilePath) ? trim(file_get_contents($tokenFilePath)) : '';
$connectionStatus = checkConnectionStatus($token); // Initialize $connectionStatus for the initial page load

// Function to check connection status
function checkConnectionStatus($token) {
    $url = "http://localhost:21465/api/default/check-connection-session";
    $headers = [
        "Accept: application/json",
        "Content-Type: application/json; charset=utf-8",
        "Authorization: Bearer $token"
    ];

    // Initialize cURL session
    $ch = curl_init();

    // Set cURL options for connection check
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    // Execute cURL request for connection check
    $response = curl_exec($ch);

    // Check for errors
    if (curl_errno($ch)) {
        echo 'Error: ' . curl_error($ch);
    }

    // Close cURL session
    curl_close($ch);

    // Decode and return the API response
    return json_decode($response, true);
}

// Function to fetch message templates from the database
function getMessageTemplates() {
    // Replace this with your database connection code
    $servername = "localhost";
    $username = "cron";
    $password = "1234";
    $dbname = "asterisk";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $templates = [];

    // Fetch templates from the database
    $sql = "SELECT template_id, template_name, template_content FROM message_templates";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $templates[] = $row;
        }
    }

    // Close connection
    $conn->close();

    return $templates;
}

// Function to send a message
function sendMessage($token, $phone, $message) {
    $url = "http://localhost:21465/api/default/send-message";

    // Initialize cURL session
    $ch = curl_init();

    // Set cURL options
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Accept: application/json",
        "Content-Type: application/json; charset=utf-8",
        "Authorization: Bearer $token"
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
        "phone" => $phone,
        "message" => $message
    ]));

    // Execute cURL request
    $response = curl_exec($ch);

    // Check for errors
    if (curl_errno($ch)) {
        echo '<p style="color: red; font-weight: bold;">Error: ' . curl_error($ch) . '</p>';
    }

    // Close cURL session
    curl_close($ch);

    // Process the API response as needed
    $decodedResponse = json_decode($response, true);

    // Check if the response is valid JSON
    if (json_last_error() != JSON_ERROR_NONE) {
        echo '<p style="color: red; font-weight: bold;">Error decoding JSON: ' . json_last_error_msg() . '</p>';
        echo '<p style="color: red; font-weight: bold;">Raw Response: ' . $response . '</p>';
    } else {
        echo '<p style="color: green; font-weight: bold;">Message sent successfully!</p>';
    }
}

// Function to send an image
function sendImage($token, $phone, $isGroup, $path, $caption) {
    $url = "http://localhost:21465/api/default/send-image";

    // Check if the file exists and is readable
    if (!file_exists($path) || !is_readable($path)) {
        echo '<p style="color: red; font-weight: bold;">Error: File does not exist or is not readable.</p>';
        return;
    }

    // Initialize cURL session
    $ch = curl_init();

    // Set cURL options
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Accept: application/json",
        "Content-Type: application/json; charset=utf-8",
        "Authorization: Bearer $token"
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
        "phone" => $phone,
        "isGroup" => $isGroup,
        "path" => $path,
        "caption" => $caption
    ]));

    // Execute cURL request
    $response = curl_exec($ch);

    // Check for errors
    if (curl_errno($ch)) {
        echo '<p style="color: red; font-weight: bold;">Error: ' . curl_error($ch) . '</p>';
    }

    // Close cURL session
    curl_close($ch);

    // Process the API response as needed
    $decodedResponse = json_decode($response, true);

    // Check if the response is valid JSON
    if (json_last_error() != JSON_ERROR_NONE) {
        echo '<p style="color: red; font-weight: bold;">Error decoding JSON: ' . json_last_error_msg() . '</p>';
        echo '<p style="color: red; font-weight: bold;">Raw Response: ' . $response . '</p>';
    } else {
        echo '<p style="color: green; font-weight: bold;">Image sent successfully!</p>';
    }
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the token from the POST data
    $token = isset($token) ? $token : null;

    if ($token === null) {
        echo '<p style="color: red; font-weight: bold;">Token is missing. Please check your form submission.</p>';
        // Add further handling or redirection if needed
        exit; // Stop execution
    }

    // Check connection status again after form submission
    $connectionStatus = checkConnectionStatus($token);

    // Display form only if the connection is still successful
    if ($connectionStatus['status']) {
        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit"])) {
            // Get phone number and message from the form
            $phone = isset($_POST["phone"]) ? $_POST["phone"] : null;

// Check if a template is selected
if (isset($_POST["template"]) && !empty($_POST["template"])) {
    // If a template is selected, use the template content
    $message = $_POST["template"];
} else {
    // If no template is selected, use the user-typed message
    $message = isset($_POST["message"]) ? $_POST["message"] : null;
}

// Call the sendMessage function
sendMessage($token, $phone, $message);

// Check if the image file input is not empty
if (!empty($_FILES["image"]["name"])) {
    // Get image details from the form
    $isGroup = false; // Assuming it's not a group image
    $caption = isset($_POST["caption"]) ? $_POST["caption"] : null;

    // Check if a file is selected
    if ($_FILES["image"]["error"] == UPLOAD_ERR_OK && is_uploaded_file($_FILES["image"]["tmp_name"])) {
        // Specify the upload directory path
        $uploadDir = "./upload/";

        // Move the uploaded file to the specified directory
        $uploadedFile = $uploadDir . basename($_FILES["image"]["name"]);

        if (move_uploaded_file($_FILES["image"]["tmp_name"], $uploadedFile)) {
            // Call the sendImage function
            sendImage($token, $phone, $isGroup, $uploadedFile, $caption);
        } else {
            echo '<p style="color: red; font-weight: bold;">Error moving file to the upload directory.</p>';
        }
    } else {
        echo '<p style="color: red; font-weight: bold;">Error: Please select a valid image file.</p>';
    }
} else {
    // No image file provided, you can choose to display a message or handle it accordingly
    echo '<p style="color: red; font-weight: bold;">Error: No image file selected.</p>';
}

        }
    } else {
        // Connection failed after form submission, display error message
        echo '<p style="color: red; font-weight: bold;">Error: ' . $connectionStatus['message'] . '</p>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send Message</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 20px;
        }

        form {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 20px;
            max-width: 600px;
            margin: auto;
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        input, select, textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #25D366;
            color: #fff;
            cursor: pointer;
        }

        .content {
    max-width: 600px;
    margin: 20px auto;
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

label {
    display: block;
    margin-bottom: 8px;
    color: #075e54;
}

input[type="text"],
textarea,
select {
    width: 100%;
    padding: 10px;
    margin-bottom: 16px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}

input[type="submit"] {
    background-color: #25D366;
    color: #fff;
    padding: 10px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type="submit"]:hover {
    background-color: #128C7E;
}
    </style>
</head>
<body>

    
    <div class="content">
    <h2>Send Message</h2>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" enctype="multipart/form-data">
        <label for="phone">Phone Number:</label>
        <input type="text" name="phone" id="phone" required>

        <label for="message">Send Message:</label>
        <textarea name="message" id="message" rows="4" cols="50"></textarea>

        <label for="image">Select File:</label>
        <input type="file" name="image" id="image">

        <label for="caption">Caption:</label>
        <input type="text" name="caption" id="caption">

        <label for="template">Select Template:</label>
        <select name="template" id="template" onchange="loadTemplateContent()">
            <option value="">Select Template</option>
            <?php
            $messageTemplates = getMessageTemplates();
            foreach ($messageTemplates as $template) {
                echo '<option value="' . htmlspecialchars($template['template_content']) . '" data-content="' . htmlspecialchars($template['template_content']) . '">' . $template['template_name'] . '</option>';
            }
            ?>
        </select>
        

        <script>
    document.addEventListener("DOMContentLoaded", function () {
        var templateDropdown = document.getElementById("template");
        var messageTextbox = document.getElementById("message");

        // Initial loading of template content
        loadTemplateContent();

        templateDropdown.addEventListener("change", function () {
            loadTemplateContent();
        });

        function loadTemplateContent() {
            // Get the selected template content
            var selectedTemplateIndex = templateDropdown.selectedIndex;
            var selectedTemplateContent = templateDropdown.options[selectedTemplateIndex].getAttribute('data-content');

            // Fill the message textarea with the selected template content
            messageTextbox.value = selectedTemplateContent;
        }
    });
</script>




        <input type="submit" name="submit" value="Send Message">
    </form>
</body>
</html>
