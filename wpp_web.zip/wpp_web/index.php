<?php include 'header.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Session Management</title>
    <style>
            /* WhatsApp-style button */
        .whatsapp-button {
            background-color: #25D366;
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 4px;
            margin-top: 10px;
            display: inline-block;
            text-decoration: none;
            text-align: center;
        }

        form {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 20px;
            text-align: center;
            display: inline-block; /* Added to center align the form */
        }

        input[type="submit"],
        .whatsapp-button.login-button { /* Matching styles for both buttons */
            background-color: #25D366;
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 4px;
            margin-top: 10px;
            display: inline-block;
            text-decoration: none;
            text-align: center;
            width: auto; /* Adjusted width to match the "Start Session" button */
        }

        input[type="submit"]:hover,
        .whatsapp-button.login-button:hover { /* Hover styles for both buttons */
            background-color: #128C7E;
        }

        .output {
            margin-top: 20px; /* Create space above the output */
            text-align: center;
        }

        .output h3 {
            color: #333;
        }

        /* Redesigned output section for a professional look */
        .output-container {
            background-color: #f9f9f9;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin: 20px;
            text-align: left;
        }

        .output-label {
            font-weight: bold;
        }

        .output-value {
            font-style: italic;
        }

    </style>
    <script>
        function toggleConfirmationButton() {
            var confirmationButton = document.getElementById('confirmationButton');
            confirmationButton.style.display = 'block';
        }

        function openLoginLink() {
            window.open('http://192.168.0.201:8080/login', '_blank');
        }

        function validateForm() {
            // Your validation logic here
            return true; // Replace with your validation condition
        }
    </script>
</head>
<body>
<?php
function generateToken($sessionName) {
    $url = "http://localhost:21465/api/$sessionName/default/generate-token";

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        echo 'Error: ' . curl_error($ch);
    }

    curl_close($ch);

    $decodedResponse = json_decode($response, true);

    if (json_last_error() != JSON_ERROR_NONE) {
        echo 'Error decoding JSON: ' . json_last_error_msg();
        echo 'Raw Response: ' . $response;
        return null;
    } else {
        return isset($decodedResponse['token']) ? $decodedResponse['token'] : null;
    }
}

?>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    <h2>Wpp Application</h2>
    <input type="hidden" name="session_name" value="default">
    <br>
    <input type="submit" name="start_session" value="Start Session">
</form>

<?php
// Output section
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["start_session"])) {
        // Your logic for generating the output
        $sessionName = 'default';
        $token = generateToken($sessionName);
        
        echo "<div class='output-container'>";
        echo "<h3>Session Name: $sessionName</h3>";
        echo "<h3>Generated Token: $token</h3>";

        if ($token) {
            $file = 'token.txt';
            file_put_contents($file, $token);
            echo "<p>Save this for for login </p>";
        }

        echo '<a href="http://192.168.0.201:8080/login" target="_blank" class="whatsapp-button login-button">Login to WhatsApp</a>';
        echo "</div>";
    }
}
?>

</body>
</html>
