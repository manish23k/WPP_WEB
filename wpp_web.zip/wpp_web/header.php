<!DOCTYPE html>
<html>
<head>
    <title>Session Management</title>
    <style>
     
       body {
    font-family: 'Arial', sans-serif;
    background-color: #f5f5f5;
    margin: 0;
    padding: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100vh;
}

/* General styles */

/* Styles for the navigation bar */
.navbar {
    background-color: #075e54;
    overflow: hidden;
    width: 100%;
    position: fixed;
    top: 0;
    left: 0;
    z-index: 1000;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.navbar a {
    float: left;
    display: block;
    color: white;
    text-align: center;
    padding: 14px 20px;
    text-decoration: none;
    transition: background-color 0.3s ease;
}

.navbar a:hover {
    background-color: #128C7E;
}

/* Padding for the content to avoid being hidden under the fixed navbar */
.content {
    padding-top: 80px; /* Adjust based on the navbar height */
}
    </style>
</head>
<body>

<div class="navbar">
    <a href="sendmsg.php">Send Message</a>
    <a href="temp_add.php">Add Template</a>
    <a href=" csv_add.php">Add Csv</a>
    <a href="sendbulk.php">Send Bulk</a>
    <!-- <a href="temp_add.php">Add Template</a> -->
</div>
