<?php
//require_once 'apiRequests.php';

$sessionname = "default";
$tokenFilePath = 'token.txt';
$token = file_exists($tokenFilePath) ? trim(file_get_contents($tokenFilePath)) : '';
$connectionStatus = checkConnectionStatus($token); // Initialize $connectionStatus for the initial page load


// Function to check connection status
function checkConnectionStatus($token) {
    $url = "http://localhost:21465/api/default/check-connection-session";
    $headers = [
        "Accept: application/json",
        "Content-Type: application/json; charset=utf-8",
        "Authorization: Bearer $token"
    ];

    // Initialize cURL session
    $ch = curl_init();

    // Set cURL options for connection check
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    // Execute cURL request for connection check
    $response = curl_exec($ch);

    // Check for errors
    if (curl_errno($ch)) {
        echo 'Error: ' . curl_error($ch);
    }

    // Close cURL session
    curl_close($ch);

    // Decode and return the API response
    return json_decode($response, true);
}

// Function to send a message
function sendMessage($token, $phone, $message) {
    $url = "http://localhost:21465/api/default/send-message";

    // Initialize cURL session
    $ch = curl_init();

    // Set cURL options
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Accept: application/json",
        "Content-Type: application/json; charset=utf-8",
        "Authorization: Bearer $token"
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
        "phone" => $phone,
        "message" => $message
    ]));

    // Execute cURL request
    $response = curl_exec($ch);

    // Check for errors
    if (curl_errno($ch)) {
        echo 'Error: ' . curl_error($ch);
    }

    // Close cURL session
    curl_close($ch);

    // Process the API response as needed
    $decodedResponse = json_decode($response, true);

    // Check if the response is valid JSON
    if (json_last_error() != JSON_ERROR_NONE) {
        echo 'Error decoding JSON: ' . json_last_error_msg();
        echo 'Raw Response: ' . $response;
    } else {
        echo "Message sent successfully!";
    }
}

// Function to send an image
function sendImage($token, $phone, $isGroup, $path, $caption) {
    $url = "http://localhost:21465/api/default/send-image";
    
    // Check if the file exists and is readable
    if (!file_exists($path) || !is_readable($path)) {
        echo 'Error: File does not exist or is not readable.';
        return;
    }

    // Initialize cURL session
    $ch = curl_init();

    // Set cURL options
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Accept: application/json",
        "Content-Type: application/json; charset=utf-8",
        "Authorization: Bearer $token"
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
        "phone" => $phone,
        "isGroup" => $isGroup,
        "path" => $path,
        "caption" => $caption
    ]));

    // Execute cURL request
    $response = curl_exec($ch);

    // Check for errors
    if (curl_errno($ch)) {
        echo 'Error: ' . curl_error($ch);
    }

    // Close cURL session
    curl_close($ch);

    // Process the API response as needed
    $decodedResponse = json_decode($response, true);

    // Check if the response is valid JSON
    if (json_last_error() != JSON_ERROR_NONE) {
        echo 'Error decoding JSON: ' . json_last_error_msg();
        echo 'Raw Response: ' . $response;
    } else {
        echo "Image sent successfully!";
    }
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the token from the POST data
    $token = isset($token) ? $token : null;

    if ($token === null) {
        echo 'Token is missing. Please check your form submission.';
        // Add further handling or redirection if needed
        exit; // Stop execution
    }

    // Check connection status before handling other actions
    $connectionStatus = checkConnectionStatus($token);

    if ($connectionStatus['status']) {
        // Connection is successful, continue with other actions
        if (isset($_POST["submit"])) {
            // Get phone number and message from the form
            $phone = isset($_POST["phone"]) ? $_POST["phone"] : null;
            $message = isset($_POST["message"]) ? $_POST["message"] : null;

            // Call the sendMessage function
            sendMessage($token, $phone, $message);

            // Check if the image file input is not empty
            if (!empty($_FILES["image"]["name"])) {
                // Get image details from the form
                $isGroup = false; // Assuming it's not a group image
                $caption = isset($_POST["caption"]) ? $_POST["caption"] : null;

                // Check if a file is selected
                if ($_FILES["image"]["error"] == UPLOAD_ERR_OK && is_uploaded_file($_FILES["image"]["tmp_name"])) {
                    // Specify the upload directory path
                    $uploadDir = "/srv/www/htdocs/wp-test/upload/";

                    // Move the uploaded file to the specified directory
                    $uploadedFile = $uploadDir . basename($_FILES["image"]["name"]);

                    if (move_uploaded_file($_FILES["image"]["tmp_name"], $uploadedFile)) {
                        // Call the sendImage function
                        sendImage($token, $phone, $isGroup, $uploadedFile, $caption);
                    } else {
                        echo 'Error moving file to the upload directory.';
                    }
                } else {
                    echo 'Error: Please select a valid image file.';
                }
            }
        }
    } else {
        // Connection failed, stop and echo message
        echo 'API Connection Error: ' . $connectionStatus['message'];
        if (isset($connectionStatus['session']) && $connectionStatus['session'] === 'default') {
            // Start session and scan QR code here
            echo 'Please start the session and scan the QR code.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send Message</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 20px;
        }

        form {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 20px;
            max-width: 600px;
            margin: auto;
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        input, select {
            width: 100%;
            padding: 10px;
            margin-bottom: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #25D366;
            color: #fff;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" enctype="multipart/form-data">
        <label for="phone">Phone Number:</label>
        <input type="text" name="phone" id="phone" required>

        <label for="message">Message:</label>
        <input type="text" name="message" id="message">

        <label for="image">Select File:</label>
        <input type="file" name="image" id="image">

        <label for="caption">Caption:</label>
        <input type="text" name="caption" id="caption">

        <input type="submit" name="submit" value="Send Message">
    </form>
</body>
</html>
