<?php include 'sendmsg.php'; ?>

<?php
function sendBulkMessage($token, $phone, $message)
{
    $response = sendMessage($token, $phone, $message);

    if ($response === true) {
        return "Message sent successfully to $phone.";
    } else {
        return "Error sending message to $phone: $response";
    }
}

function isValidPhoneNumber($phoneNumber)
{
    return preg_match('/^\+?\d+$/', $phoneNumber);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit"])) {
    if (isset($_POST['csv_file_id'])) {
        $file_id = $_POST['csv_file_id'];
        $file_path = ""; // Get the file path from the database based on $file_id
        $csvFilePath = "/path/to/upload/directory/filename.csv"; // Update with the correct path

        if (file_exists($csvFilePath) && is_readable($csvFilePath)) {
            $data = [];
            if (($handle = fopen($csvFilePath, "r")) !== false) {
                while (($row = fgetcsv($handle, 1000, ",")) !== false) {
                    $row = array_map('trim', $row);
                    if (count($row) >= 2) {
                        $phone = $row[0];
                        $message = $row[1];

                        if (!isValidPhoneNumber($phone)) {
                            echo "Invalid phone number: $phone. Skipping...<br>";
                            continue;
                        }

                        echo "Phone: $phone, Message: $message<br>";
                        echo sendBulkMessage($token, $phone, $message) . "<br>";

                        sleep(1);
                    } else {
                        echo "Invalid data format in CSV. Each row should contain at least phone number and message.<br>";
                        continue;
                    }
                }
                fclose($handle);
            } else {
                echo "Error opening the CSV file.";
                exit;
            }

            echo "All messages have been sent.";
        } else {
            echo "CSV file not found or is not readable.";
        }
    } else {
        echo "Please select a CSV file.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Head content -->
</head>
<body>
    <div class="content">
        <h2>Send Bulk Messages from CSV</h2>
        <form method="post" enctype="multipart/form-data">
            <label for="csv_file_id">Select CSV File:</label>
            <select name="csv_file_id">
                <option value="">Select CSV File</option>
                <?php
                $csvFiles = getCSVFiles(); // Get CSV files from the database
                foreach ($csvFiles as $file) {
                    echo "<option value='{$file['file_id']}'>{$file['file_name']}</option>";
                }
                ?>
            </select>
            <br>
            <button type="submit" name="submit">Send Bulk Messages</button>
        </form>
    </div>
</body>
</html>
