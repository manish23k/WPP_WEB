<?php include 'header.php'; ?>

<?php
$host = 'localhost';
$user = 'cron';
$password = '1234';
$database = 'asterisk';

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function addCSVFile($name, $file_path)
{
    global $conn;
    $sql = "INSERT INTO csv_files (file_name, file_path) VALUES ('$name', '$file_path')";
    return $conn->query($sql);
}

function deleteCSVFile($id)
{
    global $conn;
    $sql = "DELETE FROM csv_files WHERE file_id=$id";
    return $conn->query($sql);
}

function getCSVFiles()
{
    global $conn;
    $files = [];
    $sql = "SELECT file_id, file_name, file_path FROM csv_files";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $files[] = $row;
        }
    }

    return $files;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["add_csv"])) {
        $file_name = $_POST["file_name"];

        if (isset($_FILES['csv_file']) && $_FILES['csv_file']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = "/path/to/upload/directory/"; // Update this path to the desired upload directory
            $file_path = $uploadDir . basename($_FILES["csv_file"]["name"]);

            if (move_uploaded_file($_FILES["csv_file"]["tmp_name"], $file_path)) {
                addCSVFile($file_name, $file_path);
            } else {
                echo "Error moving file to the upload directory.";
            }
        } else {
            echo "Please upload a CSV file.";
        }
    } elseif (isset($_POST["delete_csv"])) {
        $file_id = $_POST["file_id"];
        deleteCSVFile($file_id);
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CSV Files</title>
    <style>
        /* Your CSS styles here */
    </style>
</head>

<body>
    <div class="container">
        <!-- Add CSV File Form -->
        <h2>Add CSV File</h2>
        <form method="post" action="" enctype="multipart/form-data">
            <label for="file_name">File Name:</label>
            <input type="text" name="file_name" required>
            <br>
            <label for="csv_file">Upload CSV File:</label>
            <input type="file" name="csv_file" required>
            <br>
            <button type="submit" name="add_csv">Add CSV File</button>
        </form>

        <!-- Existing CSV Files Table -->
        <h2>Existing CSV Files</h2>
        <table>
            <tr>
                <th>File ID</th>
                <th>File Name</th>
                <th>File Path</th>
                <th>Delete</th>
            </tr>

            <?php
            $csvFiles = getCSVFiles();
            foreach ($csvFiles as $file) {
                echo "<tr>
                        <td>{$file['file_id']}</td>
                        <td>{$file['file_name']}</td>
                        <td>{$file['file_path']}</td>
                        <td>
                            <form method='post' action=''>
                                <input type='hidden' name='file_id' value='{$file['file_id']}'>
                                <button type='submit' name='delete_csv'>Delete</button>
                            </form>
                        </td>
                    </tr>";
            }
            ?>
        </table>
    </div>
</body>

</html>
