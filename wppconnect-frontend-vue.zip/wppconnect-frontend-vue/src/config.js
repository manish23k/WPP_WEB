const config = {
  IP_SERVER: "http://192.168.0.14:21465/api/",
  IP_SOCKET_IO: "http://192.168.0.14:21465/",
  TOKEN_KEY: "@WPPConnect-Token",
  LANGUAGE: "en-US", // Available: en-US, pt-BR,
};
export default config;
