import config from "../config";

export const language = () => {
  return getLanguage(config.LANGUAGE);
};
/**
 * Função que busca todas as traduções disponiveis e retorna
 * @param {pt-BR ou en-US} lang
 * @returns
 */
export function getLanguage(lang) {
  if (lang == "pt-BR") {
    return {
      chooseContact: "Choose a contact to start a conversation",
      contacts: "Contacts",
      searchContacts: "Search contacts",
      name: "Name",
      phone: "Phone",
      participants: "Partcipants",
      groups: "Groups",
      searchGroup: "Search groups...",
      inviteParticipants: "Invite partcipants",
      inviteParticipantsText: "Invite participants to your groups quickly.",
      pleaseWait: "Please, wait...",
      allGroups: "All Groups",
      allGroupsText: "Manage all your groups.",
      createGroup: "Create Group",
      createGroupText: "Create a WhatsApp group in an automated way.",
    };
  }
  if (lang == "en-US") {
    return {
      chooseContact: "Choose a contact to start a conversation",
      contacts: "Contacts",
      searchContacts: "Search contacts",
      name: "Name",
      phone: "Phone",
      participants: "Partcipants",
      groups: "Groups",
      searchGroup: "Search groups...",
      inviteParticipants: "Invite partcipants",
      inviteParticipantsText: "Invite participants to your groups quickly.",
      pleaseWait: "Please, wait...",
      allGroups: "All Groups",
      allGroupsText: "Manage all your groups.",
      createGroup: "Create Group",
      createGroupText: "Create a WhatsApp group in an automated way.",
      settings: "Settings",
      general: "General",
      generalText: "General system settings",
      buttons: "Buttons",
      buttonsText: "Configure buttons to send to your contacts",
      list: "Lists",
      listText: "Configure list sections to send to your contacts",
    };
  }
}
